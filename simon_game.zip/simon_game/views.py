from typing import Dict, Optional, Tuple
import math
import pygame
from config import Colors, WindowConfig, ButtonConfig, FontConfig, ColorName, GameState


class ButtonRenderer:
    def __init__(self, screen: pygame.Surface):
        self._screen = screen
        self._colors = Colors()
        self._buttons: Dict[ColorName, pygame.Rect] = {}
        self._init_button_positions()

    def _init_button_positions(self) -> None:
        center_x = WindowConfig.WIDTH // 2
        center_y = WindowConfig.HEIGHT // 2 + ButtonConfig.CENTER_Y_OFFSET
        size = ButtonConfig.SIZE
        margin = ButtonConfig.MARGIN

        self._buttons = {
            ColorName.RED: pygame.Rect(
                center_x - size - margin, center_y - size - margin,
                size, size
            ),
            ColorName.GREEN: pygame.Rect(
                center_x + margin, center_y - size - margin,
                size, size
            ),
            ColorName.BLUE: pygame.Rect(
                center_x - size - margin, center_y + margin,
                size, size
            ),
            ColorName.YELLOW: pygame.Rect(
                center_x + margin, center_y + margin,
                size, size
            ),
        }

    def get_button_rects(self) -> Dict[ColorName, pygame.Rect]:
        return self._buttons.copy()

    def get_button_at_position(self, pos: Tuple[int, int]) -> Optional[ColorName]:
        for color, rect in self._buttons.items():
            if rect.collidepoint(pos):
                return color
        return None

    def draw_button(self, color_name: ColorName, is_highlight: bool = False) -> None:
        rect = self._buttons[color_name]
        base_color = self._colors.get_button_color(color_name, is_highlight)

        shadow_rect = rect.copy()
        shadow_rect.x += 5
        shadow_rect.y += 5
        pygame.draw.rect(self._screen, (0, 0, 0, 50), shadow_rect,
                         border_radius=ButtonConfig.BORDER_RADIUS)

        pygame.draw.rect(self._screen, base_color, rect,
                         border_radius=ButtonConfig.BORDER_RADIUS)

        pygame.draw.rect(self._screen, self._colors.WHITE, rect, 3,
                         border_radius=ButtonConfig.BORDER_RADIUS)

        font = pygame.font.Font(None, FontConfig.BUTTON_SIZE)
        text = font.render(color_name.value, True, self._colors.WHITE)
        text_rect = text.get_rect(center=rect.center)
        self._screen.blit(text, text_rect)

    def draw_all_buttons(self, highlighted_color: Optional[ColorName] = None) -> None:
        for color in ColorName:
            is_highlight = (highlighted_color == color)
            self.draw_button(color, is_highlight)


class UIRenderer:
    def __init__(self, screen: pygame.Surface):
        self._screen = screen
        self._colors = Colors()
        self._button_renderer = ButtonRenderer(screen)

        self._new_game_button = pygame.Rect(
            WindowConfig.WIDTH // 2 - 100,
            WindowConfig.HEIGHT - 70,
            200, 50
        )

        self._font_title = pygame.font.Font(None, FontConfig.TITLE_SIZE)
        self._font_score = pygame.font.Font(None, FontConfig.SCORE_SIZE)
        self._font_status = pygame.font.Font(None, FontConfig.STATUS_SIZE)

    @property
    def new_game_button_rect(self) -> pygame.Rect:
        return self._new_game_button

    @property
    def button_renderer(self) -> ButtonRenderer:
        return self._button_renderer

    def draw_gradient_background(self) -> None:
        for i in range(WindowConfig.HEIGHT):
            alpha = i / WindowConfig.HEIGHT
            color = (
                int(self._colors.BACKGROUND[0] * (1 - alpha) + self._colors.PANEL_BG[0] * alpha),
                int(self._colors.BACKGROUND[1] * (1 - alpha) + self._colors.PANEL_BG[1] * alpha),
                int(self._colors.BACKGROUND[2] * (1 - alpha) + self._colors.PANEL_BG[2] * alpha)
            )
            pygame.draw.line(self._screen, color, (0, i), (WindowConfig.WIDTH, i))

    def draw_score_panel(self, score: int) -> None:
        panel_rect = pygame.Rect(50, 20, WindowConfig.WIDTH - 100, 120)
        pygame.draw.rect(self._screen, self._colors.PANEL_BG, panel_rect,
                         border_radius=20)
        pygame.draw.rect(self._screen, self._colors.WHITE, panel_rect, 2,
                         border_radius=20)

        title = self._font_title.render("SIMON GAME", True, self._colors.WHITE)
        title_rect = title.get_rect(center=(WindowConfig.WIDTH // 2, 55))
        self._screen.blit(title, title_rect)

        score_text = self._font_score.render(f"Счёт: {score}", True,
                                             self._colors.YELLOW_LIGHT)
        score_rect = score_text.get_rect(center=(WindowConfig.WIDTH // 2, 105))
        self._screen.blit(score_text, score_rect)

    def draw_status(self, state: GameState, score: int) -> None:
        if state == GameState.PLAYING:
            status = "Воспроизведение..."
            status_color = self._colors.BLUE_LIGHT
        elif state == GameState.WAITING:
            status = "Ваш ход!"
            status_color = self._colors.GREEN_LIGHT
        elif state == GameState.GAME_OVER:
            status = f"ИГРА ОКОНЧЕНА!"
            status_color = self._colors.ERROR
        else:
            status = "Нажмите 'Новая игра'"
            status_color = self._colors.WHITE

        status_text = self._font_status.render(status, True, status_color)
        status_rect = status_text.get_rect(center=(WindowConfig.WIDTH // 2,
                                                   WindowConfig.HEIGHT - 100))
        self._screen.blit(status_text, status_rect)

        if state == GameState.GAME_OVER:
            score_text = self._font_status.render(f"Ваш счёт: {score}", True,
                                                  self._colors.WHITE)
            score_rect = score_text.get_rect(center=(WindowConfig.WIDTH // 2,
                                                     WindowConfig.HEIGHT - 60))
            self._screen.blit(score_text, score_rect)

    def draw_new_game_button(self, is_hovered: bool = False) -> None:
        button_color = self._colors.BUTTON_HOVER if is_hovered else self._colors.PANEL_BG
        pygame.draw.rect(self._screen, button_color, self._new_game_button,
                         border_radius=10)
        pygame.draw.rect(self._screen, self._colors.WHITE, self._new_game_button, 2,
                         border_radius=10)

        text = self._font_status.render("Новая игра", True, self._colors.WHITE)
        text_rect = text.get_rect(center=self._new_game_button.center)
        self._screen.blit(text, text_rect)

    def draw_effects(self, error_time: int, success_time: int) -> None:
        current_time = pygame.time.get_ticks()

        if error_time and current_time - error_time < 1000:
            flash_alpha = abs(math.sin(current_time * 0.01)) * 100
            flash_surface = pygame.Surface((WindowConfig.WIDTH, WindowConfig.HEIGHT))
            flash_surface.set_alpha(flash_alpha)
            flash_surface.fill(self._colors.ERROR)
            self._screen.blit(flash_surface, (0, 0))

    def render(self, score: int, state: GameState,
               highlighted_color: Optional[ColorName] = None,
               is_new_game_hovered: bool = False,
               error_time: int = 0,
               success_time: int = 0) -> None:
        self.draw_gradient_background()
        self.draw_score_panel(score)
        self.draw_status(state, score)
        self.draw_new_game_button(is_new_game_hovered)
        self._button_renderer.draw_all_buttons(highlighted_color)
        self.draw_effects(error_time, success_time)
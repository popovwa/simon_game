import sys
import pygame
from config import WindowConfig
from views import UIRenderer
from services import SoundService
from controllers import GameController


def main():
    pygame.init()
    screen = pygame.display.set_mode((WindowConfig.WIDTH, WindowConfig.HEIGHT))
    pygame.display.set_caption(WindowConfig.TITLE)

    sound_service = SoundService()
    ui_renderer = UIRenderer(screen)
    game_controller = GameController(ui_renderer, sound_service)

    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    game_controller.handle_click(event.pos)
            elif event.type == pygame.MOUSEMOTION:
                game_controller.update_hover_state(event.pos)


        game_controller.update()


        game_controller.render()
        pygame.display.flip()


        clock.tick(WindowConfig.FPS)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
from typing import Optional, Tuple
import pygame
from config import GameState, ColorName, ButtonConfig, SoundConfig
from models import GameData, AnimationState
from services import SoundService, SequenceGenerator
from views import UIRenderer


class PlaybackController:
    def __init__(self):
        self._sequence: list = []
        self._current_index = 0
        self._last_play_time = 0
        self._is_playing = False

    def start_playback(self, sequence: list) -> None:
        self._sequence = sequence.copy()
        self._current_index = 0
        self._is_playing = True
        self._last_play_time = pygame.time.get_ticks()

    def stop_playback(self) -> None:
        self._is_playing = False
        self._sequence = []
        self._current_index = 0

    def is_playing(self) -> bool:
        return self._is_playing

    def get_next_color(self) -> Optional[ColorName]:
        current_time = pygame.time.get_ticks()

        if not self._is_playing:
            return None

        if self._current_index >= len(self._sequence):
            self._is_playing = False
            return None

        if current_time - self._last_play_time >= SoundConfig.PLAYBACK_DELAY:
            color = self._sequence[self._current_index]
            self._current_index += 1
            self._last_play_time = current_time
            return color

        return None

    def is_complete(self) -> bool:
        return not self._is_playing and self._current_index >= len(self._sequence)


class GameController:
    def __init__(self, ui_renderer: UIRenderer, sound_service: SoundService):
        self._ui = ui_renderer
        self._sound_service = sound_service

        self._game_data = GameData()
        self._animation_state = AnimationState()

        self._playback_controller = PlaybackController()

        self._state = GameState.IDLE
        self._is_new_game_hovered = False
        self._waiting_for_round_delay = False
        self._round_delay_timer = 0

    def get_state(self) -> GameState:
        return self._state

    def get_score(self) -> int:
        return self._game_data.get_current_score()

    def get_highlighted_color(self) -> Optional[ColorName]:
        current_time = pygame.time.get_ticks()
        if (self._animation_state.highlighted_color and
                current_time - self._animation_state.highlight_start_time < ButtonConfig.HIGHLIGHT_DURATION_MS):
            return self._animation_state.highlighted_color
        return None

    def start_new_game(self) -> None:
        self._game_data.reset()
        self._animation_state = AnimationState()

        first_color = SequenceGenerator.generate_random_color()
        self._game_data.add_to_sequence(first_color)

        self._playback_controller.start_playback(self._game_data.sequence)
        self._state = GameState.PLAYING
        self._waiting_for_round_delay = False

    def _handle_player_move(self, color: ColorName) -> None:
        if self._state != GameState.WAITING:
            return

        self._animation_state.start_highlight(color, pygame.time.get_ticks())
        self._sound_service.play_color_sound(color)

        self._game_data.add_player_move(color)
        move_index = len(self._game_data.player_sequence) - 1

        if not self._game_data.is_player_move_correct(move_index):
            self._animation_state.start_error_effect(pygame.time.get_ticks())
            self._sound_service.play_error_sound()
            self._state = GameState.GAME_OVER
            return

        if self._game_data.is_round_complete():
            self._sound_service.play_success_sound()

            new_color = SequenceGenerator.generate_random_color()
            self._game_data.advance_round(new_color)

            self._waiting_for_round_delay = True
            self._round_delay_timer = pygame.time.get_ticks()
            self._state = GameState.IDLE

    def handle_click(self, pos: Tuple[int, int]) -> bool:
        if self._ui.new_game_button_rect.collidepoint(pos):
            self.start_new_game()
            return True

        clicked_color = self._ui.button_renderer.get_button_at_position(pos)
        if clicked_color and self._state == GameState.WAITING:
            self._handle_player_move(clicked_color)
            return True

        return False

    def update_hover_state(self, mouse_pos: Tuple[int, int]) -> None:
        self._is_new_game_hovered = self._ui.new_game_button_rect.collidepoint(mouse_pos)

    def update(self) -> None:
        current_time = pygame.time.get_ticks()

        if self._waiting_for_round_delay:
            if current_time - self._round_delay_timer >= SoundConfig.ROUND_DELAY:
                self._waiting_for_round_delay = False
                self._playback_controller.start_playback(self._game_data.sequence)
                self._state = GameState.PLAYING
            return

        if self._state == GameState.PLAYING:
            next_color = self._playback_controller.get_next_color()
            if next_color:
                self._animation_state.start_highlight(next_color, current_time)
                self._sound_service.play_color_sound(next_color)

            if self._playback_controller.is_complete():
                self._state = GameState.WAITING

    def render(self) -> None:
        self._ui.render(
            score=self._game_data.get_current_score(),
            state=self._state,
            highlighted_color=self.get_highlighted_color(),
            is_new_game_hovered=self._is_new_game_hovered,
            error_time=self._animation_state.error_effect_time,
            success_time=self._animation_state.success_effect_time
        )
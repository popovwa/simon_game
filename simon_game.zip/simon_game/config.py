from dataclasses import dataclass
from typing import Tuple
from enum import Enum


class ColorName(str, Enum):
    RED = "RED"
    GREEN = "GREEN"
    BLUE = "BLUE"
    YELLOW = "YELLOW"


class GameState(str, Enum):
    IDLE = "idle"
    PLAYING = "playing"
    WAITING = "waiting"
    GAME_OVER = "game_over"


@dataclass(frozen=True)
class Colors:
    BACKGROUND: Tuple[int, int, int] = (20, 20, 35)
    PANEL_BG: Tuple[int, int, int] = (30, 30, 50)

    WHITE: Tuple[int, int, int] = (255, 255, 255)
    BLACK: Tuple[int, int, int] = (0, 0, 0)

    RED: Tuple[int, int, int] = (220, 40, 40)
    RED_LIGHT: Tuple[int, int, int] = (255, 80, 80)
    RED_DARK: Tuple[int, int, int] = (150, 20, 20)

    GREEN: Tuple[int, int, int] = (40, 200, 40)
    GREEN_LIGHT: Tuple[int, int, int] = (80, 255, 80)
    GREEN_DARK: Tuple[int, int, int] = (20, 130, 20)

    BLUE: Tuple[int, int, int] = (40, 80, 220)
    BLUE_LIGHT: Tuple[int, int, int] = (80, 120, 255)
    BLUE_DARK: Tuple[int, int, int] = (20, 50, 150)

    YELLOW: Tuple[int, int, int] = (220, 180, 40)
    YELLOW_LIGHT: Tuple[int, int, int] = (255, 220, 80)
    YELLOW_DARK: Tuple[int, int, int] = (150, 110, 20)

    BUTTON_HOVER: Tuple[int, int, int] = (60, 60, 80)
    SUCCESS: Tuple[int, int, int] = (0, 200, 0)
    ERROR: Tuple[int, int, int] = (200, 0, 0)

    def get_button_color(self, color_name: ColorName, is_highlight: bool = False) -> Tuple[int, int, int]:
        if is_highlight:
            colors = {
                ColorName.RED: self.RED_LIGHT,
                ColorName.GREEN: self.GREEN_LIGHT,
                ColorName.BLUE: self.BLUE_LIGHT,
                ColorName.YELLOW: self.YELLOW_LIGHT,
            }
        else:
            colors = {
                ColorName.RED: self.RED,
                ColorName.GREEN: self.GREEN,
                ColorName.BLUE: self.BLUE,
                ColorName.YELLOW: self.YELLOW,
            }
        return colors.get(color_name, self.WHITE)


@dataclass(frozen=True)
class WindowConfig:
    WIDTH: int = 900
    HEIGHT: int = 800
    TITLE: str = "Simon Game - Тренировка памяти"
    FPS: int = 60


@dataclass(frozen=True)
class ButtonConfig:
    SIZE: int = 200
    MARGIN: int = 25
    BORDER_RADIUS: int = 15
    HIGHLIGHT_DURATION_MS: int = 400
    CENTER_Y_OFFSET: int = 30
    TOP_PANEL_HEIGHT: int = 140


@dataclass(frozen=True)
class SoundConfig:
    RED_FREQ: int = 523
    GREEN_FREQ: int = 587
    BLUE_FREQ: int = 659
    YELLOW_FREQ: int = 698
    ERROR_FREQ: int = 220
    SUCCESS_FREQ: int = 784

    COLOR_SOUND_DURATION: int = 300
    ERROR_DURATION: int = 600
    SUCCESS_DURATION: int = 400

    PLAYBACK_DELAY: int = 700
    ROUND_DELAY: int = 800


@dataclass(frozen=True)
class FontConfig:
    TITLE_SIZE: int = 72
    SCORE_SIZE: int = 48
    STATUS_SIZE: int = 36
    BUTTON_SIZE: int = 28
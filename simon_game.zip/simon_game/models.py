from typing import List, Optional
from dataclasses import dataclass, field
from config import ColorName


@dataclass
class GameData:
    sequence: List[ColorName] = field(default_factory=list)
    player_sequence: List[ColorName] = field(default_factory=list)
    score: int = 0

    def reset(self) -> None:
        self.sequence.clear()
        self.player_sequence.clear()
        self.score = 0

    def add_to_sequence(self, color: ColorName) -> None:
        self.sequence.append(color)

    def add_player_move(self, color: ColorName) -> None:
        self.player_sequence.append(color)

    def clear_player_sequence(self) -> None:
        self.player_sequence.clear()

    def advance_round(self, next_color: ColorName) -> None:
        self.sequence.append(next_color)
        self.score = len(self.sequence)
        self.clear_player_sequence()

    def is_player_move_correct(self, move_index: int) -> bool:
        if move_index >= len(self.sequence):
            return False
        return self.player_sequence[move_index] == self.sequence[move_index]

    def is_round_complete(self) -> bool:
        return len(self.player_sequence) == len(self.sequence)

    def get_current_score(self) -> int:
        return len(self.sequence)


@dataclass
class AnimationState:
    highlighted_color: Optional[ColorName] = None
    highlight_start_time: int = 0
    error_effect_time: int = 0
    success_effect_time: int = 0

    def start_highlight(self, color: ColorName, current_time: int) -> None:
        self.highlighted_color = color
        self.highlight_start_time = current_time

    def clear_highlight(self) -> None:
        self.highlighted_color = None

    def start_error_effect(self, current_time: int) -> None:
        self.error_effect_time = current_time

    def start_success_effect(self, current_time: int) -> None:
        self.success_effect_time = current_time
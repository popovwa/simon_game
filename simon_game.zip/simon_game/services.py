import random
from typing import List, Optional
import pygame
from config import ColorName, SoundConfig


class SequenceGenerator:

    @staticmethod
    def generate_random_color() -> ColorName:
        return random.choice(list(ColorName))

    @staticmethod
    def generate_initial_sequence() -> List[ColorName]:
        return [SequenceGenerator.generate_random_color()]

    @staticmethod
    def extend_sequence(sequence: List[ColorName]) -> List[ColorName]:
        new_sequence = sequence.copy()
        new_sequence.append(SequenceGenerator.generate_random_color())
        return new_sequence


class SoundService:

    def __init__(self):
        pygame.mixer.init(frequency=44100, size=-16, channels=1)
        self._sound_cache = {}
        self._init_sounds()

    def _init_sounds(self) -> None:
        pass

    def _generate_sound(self, frequency: int, duration_ms: int) -> Optional[pygame.mixer.Sound]:
        try:
            sample_rate = 44100
            n_samples = int(sample_rate * duration_ms / 1000)

            # Генерация синусоидальной волны
            buf = pygame.sndarray.array(
                [int(32767 * 0.3 * (pygame.math.Vector2(1, 0).rotate(
                    360 * frequency * t / sample_rate).x))
                 for t in range(n_samples)]
            )
            return pygame.mixer.Sound(buf)
        except Exception:
            return None

    def play_color_sound(self, color: ColorName) -> None:
        freq_map = {
            ColorName.RED: SoundConfig.RED_FREQ,
            ColorName.GREEN: SoundConfig.GREEN_FREQ,
            ColorName.BLUE: SoundConfig.BLUE_FREQ,
            ColorName.YELLOW: SoundConfig.YELLOW_FREQ,
        }
        frequency = freq_map.get(color, 440)
        sound = self._generate_sound(frequency, SoundConfig.COLOR_SOUND_DURATION)
        if sound:
            sound.play()

    def play_error_sound(self) -> None:
        sound = self._generate_sound(SoundConfig.ERROR_FREQ, SoundConfig.ERROR_DURATION)
        if sound:
            sound.play()

    def play_success_sound(self) -> None:
        sound = self._generate_sound(SoundConfig.SUCCESS_FREQ, SoundConfig.SUCCESS_DURATION)
        if sound:
            sound.play()


class GameLogic:

    def __init__(self, sound_service: SoundService):
        self._sound_service = sound_service
        self._game_data = None
        self._current_round = 0

    def set_game_data(self, game_data) -> None:
        self._game_data = game_data

    def start_new_game(self) -> List[ColorName]:
        if self._game_data:
            self._game_data.reset()
            initial_sequence = SequenceGenerator.generate_initial_sequence()
            for color in initial_sequence:
                self._game_data.add_to_sequence(color)
            return initial_sequence
        return []

    def process_player_move(self, color: ColorName) -> dict:
        if not self._game_data:
            return {"move_correct": False, "game_over": True, "round_complete": False}

        self._game_data.add_player_move(color)
        move_index = len(self._game_data.player_sequence) - 1

        if not self._game_data.is_player_move_correct(move_index):
            self._sound_service.play_error_sound()
            return {"move_correct": False, "game_over": True, "round_complete": False}

        if self._game_data.is_round_complete():
            self._sound_service.play_success_sound()
            next_color = SequenceGenerator.generate_random_color()
            self._game_data.advance_round(next_color)
            return {"move_correct": True, "game_over": False, "round_complete": True}

        return {"move_correct": True, "game_over": False, "round_complete": False}

    def get_current_sequence(self) -> List[ColorName]:
        return self._game_data.sequence if self._game_data else []

    def get_current_score(self) -> int:
        return self._game_data.get_current_score() if self._game_data else 0